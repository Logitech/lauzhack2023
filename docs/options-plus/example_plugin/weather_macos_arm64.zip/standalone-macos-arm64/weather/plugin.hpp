#pragma once
#include "error.hpp"

#include "logi/plugin_client.hpp"

#include <nlohmann/json.hpp>

#include <string>

namespace logi
{
    class weather_plugin final : public plugin_client
    {
    public:
        weather_plugin(const std::string &plugin_id, const std::string &version, const std::string &secret);
        ~weather_plugin();

        // logi::plugin_delegate
        void on_trigger_action(const plugin::protocol::TriggerAction &msg, const uint64_t msg_id) override;

        // Actions
        void get_weather();

    private:
        void dispatch_action(const plugin::protocol::TriggerAction &msg);
    };
}

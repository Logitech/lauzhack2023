#pragma once

namespace logi
{
    constexpr auto weather_plugin_version = "0.1.999";
    constexpr auto weather_plugin_id = "logi_weather_plugin";
}

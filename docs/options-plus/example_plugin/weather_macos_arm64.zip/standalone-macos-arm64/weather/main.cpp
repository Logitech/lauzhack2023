#include "plugin.hpp"
#include "plugin_info.hpp"

int main()
{
    std::string token = "";
    if (std::getenv("token")) {
        token = std::getenv("token");
    }

    logi::weather_plugin plugin(logi::weather_plugin_id, logi::weather_plugin_version, token);

    plugin.connect("ws://127.0.0.1:30009");
    plugin.wait_for_disconnect();

    return 0;
}

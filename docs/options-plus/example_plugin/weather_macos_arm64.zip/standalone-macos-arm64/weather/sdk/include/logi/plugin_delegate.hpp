#pragma once

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-parameter"
#include <schema/logi_plugin.pb.h>
#pragma clang diagnostic pop

namespace logi
{
    /** Use this delegate for easier message dispatching
     **/
    class plugin_delegate
    {
    public:
        virtual ~plugin_delegate() = default;

        virtual void on_connect() {};

        virtual void on_disconnect() {};

        virtual void on_manager_hello(const logi::plugin::protocol::ManagerHello &/*msg*/, const uint64_t /*msg_id*/) {}

        virtual void on_init_login(const logi::plugin::protocol::InitLogin &/*msg*/, const uint64_t /*msg_id*/) {}

        virtual void on_logout(const logi::plugin::protocol::Logout &/*msg*/, const uint64_t /*msg_id*/) {}

        virtual void on_trigger_action(const logi::plugin::protocol::TriggerAction &/*msg*/, const uint64_t /*msg_id*/) {}

        virtual void on_release_action(const logi::plugin::protocol::ReleaseAction &/*msg*/, const uint64_t /*msg_id*/) {}

        [[deprecated("Implement on_visibility_changed_list() instead")]]
        virtual void on_visibility_changed(const logi::plugin::protocol::VisibilityChanged &/*msg*/, const uint64_t /*msg_id*/) {}

        virtual void on_visibility_changed_list(const logi::plugin::protocol::VisibilityChangedList &/*msg*/, const uint64_t /*msg_id*/) {}

        virtual void on_update_analog_control(const logi::plugin::protocol::UpdateAnalogControl &/*msg*/,
                                              const uint64_t /*msg_id*/) {}

        [[deprecated("Implement on_get_action_status() instead")]]
        virtual void on_get_analog_control_value(const logi::plugin::protocol::GetAnalogControlValue &/*msg*/,
                                                 const uint64_t /*msg_id*/) {}

        virtual void on_get_action_status(const logi::plugin::protocol::GetActionStatus &/*msg*/,
                                          const uint64_t /*msg_id*/) {}

        virtual void on_plugin_action_configuration_scheme_request(
            const logi::plugin::protocol::PluginActionConfigurationSchemeRequest &/*msg*/,
            const uint64_t /*msg_id*/) {}

        virtual void on_plugin_action_configuration_response(
            const logi::plugin::protocol::PluginActionConfigurationResponse &/*msg*/,
            const uint64_t /*msg_id*/) {}

        virtual void on_saved_data(const logi::plugin::protocol::SavedData &/*msg*/, const uint64_t /*msg_id*/) {}

        virtual void on_oauth_response(const logi::plugin::protocol::OauthResponse &/*msg*/, const uint64_t /*msg_id*/) {}

        virtual void on_get_users_info(const logi::plugin::protocol::GetUserInfoList &/*msg*/, const uint64_t /*msg_id*/) {}

        /// use this default dispatcher to forward messages to separate functions in @a logi_plugin_delegate
        /// returns false if message type is unknown
        virtual bool dispatch_message(const google::protobuf::Any &/*msg*/, const uint64_t /*msg_id*/);
    };
}

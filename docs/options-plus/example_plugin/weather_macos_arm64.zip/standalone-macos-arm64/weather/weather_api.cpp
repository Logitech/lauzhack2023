#include "weather_api.hpp"

#include "logi/utils/system.hpp"

namespace weather_api
{
    namespace endpoints
    {
        constexpr auto get_weather = "https://wttr.in";
    }

    void get_weather()
    {
        /* open browser to page with local weather information */
        logi::utils::open_url(endpoints::get_weather);
    }
}

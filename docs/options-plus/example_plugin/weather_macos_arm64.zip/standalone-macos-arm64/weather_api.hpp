#pragma once

namespace weather_api
{
    void get_weather();
}

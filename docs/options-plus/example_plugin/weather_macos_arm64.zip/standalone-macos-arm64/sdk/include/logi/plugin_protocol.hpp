#pragma once

#include <google/protobuf/message.h>
#include <schema/logi_plugin.pb.h>
#include <memory>
#include <vector>

namespace logi
{

    struct Serializer
    {
        // Serializer(const Serializer &s){};
        virtual ~Serializer() {};
        virtual std::vector<char> to_data(const google::protobuf::Message &msg) = 0;
        virtual bool from_data(const std::vector<char> &data, google::protobuf::Message &msg) = 0;
        virtual bool is_binary() = 0;
    };


    struct JsonSerializer : public Serializer
    {
        virtual std::vector<char> to_data(const google::protobuf::Message &msg) override;
        virtual bool from_data(const std::vector<char> &data, google::protobuf::Message &msg) override;
        virtual bool is_binary() override;
    };

    struct BinarySerializer : public Serializer
    {
        virtual std::vector<char> to_data(const google::protobuf::Message &msg) override;
        virtual bool from_data(const std::vector<char> &data, google::protobuf::Message &msg) override;
        virtual bool is_binary() override;
    };


    /// Helper class for converting messages to/from data stream.
    class plugin_protocol
    {
    private:
        std::unique_ptr<Serializer> m_serializer;

    public:
        /// creates protocol and takes ownership over serializer
        explicit plugin_protocol(std::unique_ptr<Serializer> s);

        /// creates new message and converts it to data. @return data.
        std::vector<char> message_to_data(const google::protobuf::Message &msg) const;
        /// parses @a data and rturns Envelope struct or nullptr
        logi::plugin::protocol::Envelope *envelope_from_data(const std::vector<char> &data) const;
        /// returns true for protobuf binary format and false for json format
        bool is_binary() const;
    };


    logi::plugin::protocol::Envelope create_error_response(uint64_t msg_id,
                                                           logi::plugin::protocol::ResponseInfo::Code code,
                                                           const std::string &description = "");
    logi::plugin::protocol::Envelope create_ok_response(uint64_t msg_id);
    logi::plugin::protocol::Envelope create_response(const google::protobuf::Message &msg, uint64_t msg_id);

}

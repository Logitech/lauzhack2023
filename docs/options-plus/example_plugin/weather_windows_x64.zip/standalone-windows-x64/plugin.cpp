#include "plugin.hpp"
#include "weather_api.hpp"

#include "logi/plugin_client.hpp"

namespace logi
{
    namespace errors
    {
        constexpr auto invalid_action_id_description = "Invalid action id.";
        constexpr auto internal_description = "Internal error.";
    }

    weather_plugin::weather_plugin(const std::string &plugin_id, const std::string &version, const std::string &secret)
        : plugin_client(plugin_id, version, secret)
    {
    }

    void weather_plugin::dispatch_action(const plugin::protocol::TriggerAction &msg)
    {
        if (msg.action_id() == "get_weather")
        {
            get_weather();
        }
        else
        {
            throw plugin_error(errors::invalid_action_id, errors::invalid_action_id_description);
        }
    }

    void weather_plugin::on_trigger_action(const logi::plugin::protocol::TriggerAction &msg, const uint64_t msg_id)
    {
        try
        {
            dispatch_action(msg);

            send_ok_response(msg_id);
        }
        catch (...)
        {
            send_error_response(msg_id, logi::plugin::protocol::ResponseInfo_Code_FAULTED, errors::internal_description);
        }
    }

    void weather_plugin::get_weather()
    {
        weather_api::get_weather();
    }

    weather_plugin::~weather_plugin()
    {
    }
}

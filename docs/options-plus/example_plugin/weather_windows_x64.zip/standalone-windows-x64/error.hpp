#pragma once
#include <stdexcept>

namespace logi
{
    namespace errors
    {
        constexpr uint32_t invalid_action_id = 1;
        constexpr uint32_t invalid_action_configuration = 2;
        constexpr uint32_t no_live_broadcasts = 3;
        constexpr uint32_t state_mismatch = 4;
        constexpr uint32_t bad_request = 100;
        constexpr uint32_t internal = 200;
    }

    class base_error : public std::runtime_error
    {
    public:
        using std::runtime_error::runtime_error;
        base_error(uint32_t code, const std::string &what) : std::runtime_error(what), m_code(code) {}
        base_error(uint32_t code, const char *what) : std::runtime_error(what), m_code(code) {}

        uint32_t code() const { return m_code; }

    protected:
        uint32_t m_code = 0;
    };

    class http_error : public base_error
    {
    public:
        using base_error::base_error;
    };

    class plugin_error : public base_error
    {
    public:
        using base_error::base_error;
    };
}

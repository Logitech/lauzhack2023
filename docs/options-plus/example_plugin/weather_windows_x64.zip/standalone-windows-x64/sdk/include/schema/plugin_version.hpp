#pragma once

namespace logi::plugin
{
    static const int VERSION_MAJOR = 1;
    static const int VERSION_MINOR = 4;
    static const int VERSION_PATCH = 440511;
}

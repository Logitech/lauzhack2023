#pragma once
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-parameter"
#include <schema/logi_plugin.pb.h>
#pragma clang diagnostic pop
#include <logi/plugin_delegate.hpp>
#include <logi/plugin_protocol.hpp>
#include <logi/buffers/buffer_manager.hpp>

#include <functional>
#include <memory>
#include <websocketpp/client.hpp>
#include <websocketpp/config/asio_no_tls_client.hpp>
#include <logi/utils/async_message_dispatcher.hpp>
#include <queue>
#include <mutex>
#include <thread>
#include <atomic>
#include <condition_variable>

// websocketpp deps
typedef websocketpp::client<websocketpp::config::asio_client> client;

namespace logi
{

    // callback types
    typedef std::function<void(const std::string &)> log_function;
    /// message + response code + what
    typedef std::function<void(const google::protobuf::Any *, uint32_t, const std::string &)>
        response_handler_function;
    /// connection handle
    typedef std::function<void(websocketpp::connection_hdl)> connection_function;

    /// C++ Interface for communication with Logitech Plugin host application
    /// Responds to Ping messages automatically.
    class plugin_client: public plugin_delegate
    {
    public:
        plugin_client(std::string plugin_id, std::string version, std::string secret);
        ~plugin_client();

        /// It is possible to set your custom callback for logging functionality.
        void set_log_function(log_function f);
        /// True means json format, False - protobuf binary format.
        void set_use_text_format(bool use_text);
        /// Returns plugin ID
        const std::string &get_id() const;
        /// Returns plugin version
        const std::string &get_version() const;
        /// This setting will be applied during next connection
        void set_secret(std::string secret);
        /// Returns plugin secret
        const std::string &get_secret() const;
        /// default implementation sends required PluginHello message.
        void set_connect_handler(connection_function f);
        /// default does nothing.
        void set_disconnect_handler(connection_function f);
        /// Enable buffer for the specified controls: {control_id, buffer_name}. By default there will be no buffering
        void enable_control_buffering(const std::map<std::string, std::string> &controls);
        /// Provide your own buffer realization. Specify appropriate name for the buffer.
        void register_custom_buffer(const std::string &buffer_name, std::unique_ptr<buffer> buffer);
        /// Dispatch all the buffered items of the specific buffer before their time.
        void flush_buffer(const std::string &buffer_name);
        /// Dispatch all the buffered items of all registered buffers before their time.
        void flush_all_buffers();
        /// By enabling this all the incoming to client messages will be handled in a async separate queue.
        void enable_async_message_processing(const bool enable);

        /// call this first before calling
        void connect(const std::string &uri);
        bool is_connected() const;
        /// sends message to server, if connection is established. @return message_id generated for this call
        uint64_t send_message(const google::protobuf::Message &msg);
        /// sends message to server, if connection is established.
        /// calls on_response when it is received or timed out.
        /// @note delegate calbacks will not be called for this responces.
        /// @return message_id generated for this call
        uint64_t send_message_with_callback(const google::protobuf::Message &msg,
                                            response_handler_function on_response,
                                            const unsigned timeout_ms = 10000);
        void send_response(const google::protobuf::Message &msg, uint64_t msg_id);
        void send_error_response(uint64_t msg_id, plugin::protocol::ResponseInfo::Code result_code, const std::string &description = "");
        void send_ok_response(uint64_t msg_id);

        /// disconnects from the server.
        void wait_for_disconnect();
        void disconnect();

        /// plugin_delegate
        virtual void on_visibility_changed_list(const logi::plugin::protocol::VisibilityChangedList &/*msg*/,
                                                const uint64_t msg_id) override
        {
            send_error_response(msg_id, plugin::protocol::ResponseInfo::NOT_IMPLEMENTED);
        }

        virtual void on_release_action(const logi::plugin::protocol::ReleaseAction &/*msg*/, const uint64_t msg_id) override
        {
            send_error_response(msg_id, plugin::protocol::ResponseInfo::NOT_IMPLEMENTED);
        }

        virtual void on_init_login(const logi::plugin::protocol::InitLogin &/*msg*/, const uint64_t msg_id) override
        {
            send_error_response(msg_id, plugin::protocol::ResponseInfo::NOT_IMPLEMENTED);
        }

        virtual void on_logout(const logi::plugin::protocol::Logout &/*msg*/, const uint64_t msg_id) override
        {
            send_error_response(msg_id, plugin::protocol::ResponseInfo::NOT_IMPLEMENTED);
        }

        virtual void on_trigger_action(const logi::plugin::protocol::TriggerAction &/*msg*/, const uint64_t msg_id) override
        {
            send_error_response(msg_id, plugin::protocol::ResponseInfo::NOT_IMPLEMENTED);
        }

        virtual void on_visibility_changed(const logi::plugin::protocol::VisibilityChanged &/*msg*/, const uint64_t msg_id) override
        {
            send_error_response(msg_id, plugin::protocol::ResponseInfo::NOT_IMPLEMENTED);
        }

        virtual void on_update_analog_control(const logi::plugin::protocol::UpdateAnalogControl &/*msg*/,
                                              const uint64_t msg_id) override
                                              {
                                                send_error_response(msg_id, plugin::protocol::ResponseInfo::NOT_IMPLEMENTED);
                                              }

        virtual void on_get_analog_control_value(const logi::plugin::protocol::GetAnalogControlValue &/*msg*/,
                                                 const uint64_t msg_id) override
                                                 {
                                                    send_error_response(msg_id, plugin::protocol::ResponseInfo::NOT_IMPLEMENTED);
                                                 }

        virtual void on_plugin_action_configuration_scheme_request(
            const logi::plugin::protocol::PluginActionConfigurationSchemeRequest &/*msg*/,
            const uint64_t msg_id) override
            {
                // no configuration by default.
                send_ok_response(msg_id);
            }

        virtual void on_plugin_action_configuration_response(
            const logi::plugin::protocol::PluginActionConfigurationResponse &/*msg*/,
            const uint64_t msg_id) override
            {
                send_ok_response(msg_id);
            }

        virtual void on_saved_data(const logi::plugin::protocol::SavedData &/*msg*/, const uint64_t msg_id) override
        {
            send_error_response(msg_id, plugin::protocol::ResponseInfo::NOT_IMPLEMENTED);
        }

        virtual void on_oauth_response(const logi::plugin::protocol::OauthResponse &/*msg*/, const uint64_t msg_id) override
        {
            send_error_response(msg_id, plugin::protocol::ResponseInfo::NOT_IMPLEMENTED);
        }

        virtual void on_get_users_info(const logi::plugin::protocol::GetUserInfoList &/*msg*/, const uint64_t msg_id) override
        {
            send_error_response(msg_id, plugin::protocol::ResponseInfo::NOT_IMPLEMENTED);
        }

        virtual void on_get_action_status(const logi::plugin::protocol::GetActionStatus &/*msg*/,
                                          const uint64_t msg_id) override
        {
            send_error_response(msg_id, plugin::protocol::ResponseInfo::NOT_IMPLEMENTED);
        }

    private:
        void on_ws_connect(websocketpp::connection_hdl h);
        void on_ws_message(websocketpp::connection_hdl hdl, client::message_ptr msg);
        void on_ws_disconnect(websocketpp::connection_hdl h);
        void on_ws_fail(websocketpp::connection_hdl hdl);
        std::string get_connection_status(websocketpp::connection_hdl hdl);

        /// @returns true if message was handled by some handler.
        bool notify_listeners_about_response(const logi::plugin::protocol::Envelope &envelope);
        void clean_timed_out_response_listeners();

        void message_queue_thread_task();
        void push_message_to_queue(const logi::plugin::protocol::Envelope &message);

        void send_envelope(const logi::plugin::protocol::Envelope &msg);

    private:
        client m_client;
        websocketpp::connection_hdl m_connection;
        std::future<void> m_connection_feature;
        std::unique_ptr<plugin_protocol> m_protocol;

        struct response_listener
        {
            response_handler_function callback;
            std::chrono::time_point<std::chrono::steady_clock> timestamp;
        };
        std::map<uint64_t, response_listener> m_response_listeners;

        std::string m_plugin_id;
        std::string m_version;
        std::string m_secret;

        log_function m_log_function;
        connection_function m_connected_handler;
        connection_function m_disconnected_handler;

        std::shared_ptr<async_message_dispatcher> m_async_dispatcher;
        buffer_manager m_buffer_manager;
    };

}
